/**
明细
减去五年制9月12、9月13两天
减去22五年制一周
减去22三年制三周
加上22三年制星期四下午和星期五
减去郑杰锋，李珊，徐雨三周晚自习
减去除去郑杰锋，李珊，徐雨外的班主任一周晚自习
减去易娟的李珊带易娟商务礼仪课程3次，停课1次
加上李珊的李珊带易娟商务礼仪课程3次
减去叶保春的李珊带叶保春演讲与口才课程3次，停课1次
加上李珊的李珊带叶保春演讲与口才课程3次
减去彭润华周四1-2，22电子商务，英语
减去辛鹏的柳航带辛鹏社交礼仪课程2次
加上柳航的柳航带辛鹏社交礼仪课程2次
**/
getDetails = function (teacher) {
  const { weekKeshiShu, weekDaKeShuByGrade,name,wanzixiNum,infos } = getTeacherKeShi(teacher)
  let ret = {
    "减去22五年制一周" :1*reduceDakeShu(weekDaKeShuByGrade["22五年"])*2,
    "减去22三年制三周" :3*reduceDakeShu(weekDaKeShuByGrade["22三年"])*2,
    "减去五年制9月12、9月13两天" :~outTeachers.indexOf(teacher) ? reduceDakeShu([
      ..._.filter(weekDaKeShuByGrade["老班五年"],(info)=>{ return 'B'.charCodeAt() <= info.column.charCodeAt() && info.column.charCodeAt() <= 'I'.charCodeAt()}),
      ..._.filter(weekDaKeShuByGrade["22五年"],(info)=>{ return 'B'.charCodeAt() <= info.column.charCodeAt() && info.column.charCodeAt() <='I'.charCodeAt()})
    ])*2: 0,
    "加上22三年制星期四下午和星期五共": reduceDakeShu(_.filter(weekDaKeShuByGrade["22三年"],(info)=>{ return 'P'.charCodeAt() == info.column.charCodeAt() ||  'R'.charCodeAt() <= info.column.charCodeAt() && info.column.charCodeAt() <='S'.charCodeAt()}))*2,
    "减去叶保春一次晚自习": ~["叶保春"].indexOf(name) ? 1 * 1.9 : 0,
    "减去郑杰锋，李珊，徐雨三周晚自习": ~["郑杰锋","李珊","徐雨"].indexOf(name) ? 3 * wanzixiNum * 1.9 : 0,
    "减去易娟的李珊带易娟商务礼仪课程3次，停课1次":"易娟"===name ? 4*reduceDakeShu(_.filter(infos,(info)=>{ return 'J'.charCodeAt() == info.column.charCodeAt()}))*2:0,
    "加上李珊的李珊带易娟商务礼仪课程3次":"李珊"===name ? 3*reduceDakeShu(_.filter(getTeacherKeShi("易娟").infos,(info)=>{ return 'J'.charCodeAt() == info.column.charCodeAt()}))*2:0,
    "减去叶保春的李珊带叶保春演讲与口才课程4次，停课2次":"叶保春"===name ? 6*reduceDakeShu(_.filter(infos,(info)=>{ return 'D'.charCodeAt() == info.column.charCodeAt()}))*2:0,
    "加上李珊的李珊带叶保春演讲与口才课程5次":"李珊"===name ? 5*reduceDakeShu(_.filter(getTeacherKeShi("叶保春").infos,(info)=>{ return 'D'.charCodeAt() == info.column.charCodeAt()}))*2:0,
    "减去彭润华22电子商务，英语停课1次":"彭润华"===name ? reduceDakeShu(_.filter(infos,(info)=>{ return 'S'.charCodeAt() == info.column.charCodeAt()}))*2:0,
    "减去辛鹏的柳航带辛鹏社交礼仪课程2次":"辛鹏"===name ? 2*reduceDakeShu(_.filter(infos,(info)=>{ return 'F'.charCodeAt() == info.column.charCodeAt()}))*2:0,
    "加上柳航的柳航带辛鹏社交礼仪课程2次":"柳航"===name ? 2*reduceDakeShu(_.filter(getTeacherKeShi("辛鹏").infos,(info)=>{ return 'F'.charCodeAt() == info.column.charCodeAt()}))*2:0,
    shorts: {
      "减去叶保春一次晚自习":"减去一次晚自习",
      "减去郑杰锋，李珊，徐雨三周晚自习": "减去三周晚自习",
      "减去易娟的李珊带易娟商务礼仪课程3次，停课1次":"减去商务礼仪课程4次",
      "加上李珊的李珊带易娟商务礼仪课程3次":"加上商务礼仪课程3次",
      "减去叶保春的李珊带叶保春演讲与口才课程4次，停课2次":"减去演讲与口才课程6次",
      "加上李珊的李珊带叶保春演讲与口才课程5次":"加上演讲与口才课程5次",
      "减去彭润华22电子商务，英语停课1次":"减去英语停课1次",
      "减去辛鹏的柳航带辛鹏社交礼仪课程2次":"减去社交礼仪课程2次",
      "加上柳航的柳航带辛鹏社交礼仪课程2次":"加上社交礼仪课程2次",
    }
  }
  return ret;
}
