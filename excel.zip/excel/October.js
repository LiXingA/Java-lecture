/**
明细
减去国庆休假周一到周三3天,外聘老师减去
减去国庆休假周一到周三3天晚自习,外聘老师减去
减去22级三年制、五年制军训2周+周四、周五2天
减去军训期间只上22级老师晚自习
减去21会计第8周实训
实训班级合班课变成单班怎么算??
//肖楚煜晚自习去掉，其他代课怎么算？
//因学院10月21安排创业培训，下列5个班级明天(周五）上午1-4节停课：
20会计1班
20计应1班
20计应2班
20工业机器人1班
20机电1班
// 第9周，22机电一体化技术3和22机电一体化技术4班进行劳动周
10月28创业培训停课班级（周五1-4节）
20会计1班
20计应1班
20计应2班
20工业机器人1班
20机电1班
20电子商务1、
20电子商务2、
20计算机网络技术、
20工程造价、
20建筑工程技术
//班主任安全教育课
**/
getDetails = function (teacher) {
  const {
    weekKeshiShu,
    weekDaKeShu,
    weekDaKeShuByGrade,
    name,
    wanzixiNum,
    infos,
    wanzixiArray,
    wanzixiDetail,
  } = getTeacherKeShi(teacher);
  let getAnquan = function (teacher) {
    let clazzs = teacherConfigs[teacher].clazzs;
    if (!clazzs.length) {
      return 0;
    }
    if (~["肖继林"].indexOf(teacher)) {
      return 0;
    }
    if ("敖欢" === teacher) {
      clazzs = ["20电子商务1", "20电子商务2"];
    }
    return (
      heKeshiXishu(
        _.reduce(
          clazzs,
          (prev, clazz) => {
            prev += clazzConfigs[clazz].num;
            return prev;
          },
          0
        )
      ) * 2
    );
  };
  let _21clazzs = [
    "20会计",
    "20计算机应用技术1",
    "20计算机应用技术2",
    "20机电一体化",
    "20工业机器人",
  ];
  let _28clazzs = [
    "20电子商务1",
    "20电子商务2",
    "20计算机网络技术",
    "20工程造价",
    "20建筑工程技术",
  ];
  let ret = {
    shorts: {
      "减去22机电一体化技术4、22机电一体化技术3班第9周劳动周":
        "减去22机电3、4班劳动周",
      减去军训期间只上22级老师晚自习: "减去22级军训晚自习",
      减去10月21日周五创业培训课程: "减去21日周五停课",
      减去10月28日周五创业培训课程: "减去28日周五停课",
      "减去肖楚煜6(周四、周五),7,8周晚自习": "减去6至8周晚自习",
      "减去22级五年制和三年制两周、8、9号军训": "减去22级军训",
      减去国庆休假周一到周三3天课程: "减去国庆课程",
      减去国庆休假周一到周三3天晚自习: "减去国庆晚自习",
      减去21大数据与会计第8周实训: "减去21会计实训",
      加上21大数据与会计第8周实训: "加上21会计实训",
      "减去肖楚煜7、8周休假课程": "减去7、8周课程",
      "减去肖楚煜6(周四、周五)休假课程": "减去6周(周四、五)课程",
    },
    加上安全教育课: getAnquan(teacher),
    "减去22机电一体化技术4、22机电一体化技术3班第9周劳动周":
      shixunHeMinusKeshiXishu(infos, [
        "22机电一体化技术3",
        "22机电一体化技术4",
      ]) * 2,
    减去军训期间只上22级老师晚自习:
      (_.filter(wanzixiArray, (column) => {
        return (
          "N".charCodeAt() <= column.charCodeAt() &&
          column.charCodeAt() <= "S".charCodeAt() &&
          _.filter(wanzixiDetail[column], (clazz) => {
            return !clazz.startsWith("22");
          }).length === 0
        );
      }).length +
        2 *
          _.filter(wanzixiArray, (column) => {
            return (
              _.filter(wanzixiDetail[column], (clazz) => {
                return !clazz.startsWith("22");
              }).length === 0
            );
          }).length) *
      1.9,
    减去10月21日周五创业培训课程:
      teacher === "肖楚煜"
        ? 0
        : shixunHeMinusKeshiXishu(
            [
              ..._.filter(infos, (info) => {
                return (
//                   ~_21clazzs.indexOf(info.clazz) &&
                  "R".charCodeAt() <= info.column.charCodeAt() &&
                  info.column.charCodeAt() <= "S".charCodeAt()
                );
              }),
            ],
            _21clazzs
          ) * 2,
    减去10月28日周五创业培训课程:
      shixunHeMinusKeshiXishu(
        [
          ..._.filter(infos, (info) => {
            return (
//               ~_28clazzs.indexOf(info.clazz) &&
              "R".charCodeAt() <= info.column.charCodeAt() &&
              info.column.charCodeAt() <= "S".charCodeAt()
            );
          }),
        ],
        _28clazzs
      ) * 2,
    "减去22级五年制和三年制两周、8、9号军训":
      (2 *
        reduceDakeShu([
          ...weekDaKeShuByGrade["22五年"],
          ...weekDaKeShuByGrade["22三年"],
        ]) +
        reduceDakeShu([
          ..._.filter(infos, (info) => {
            return (
              info.clazz.startsWith("22") &&
              "N".charCodeAt() <= info.column.charCodeAt() &&
              info.column.charCodeAt() <= "S".charCodeAt()
            );
          }),
        ])) *
      2,
    减去国庆休假周一到周三3天课程: ~outTeachers.indexOf(teacher)
      ? reduceDakeShu([
          ..._.filter(infos, (info) => {
            return (
              "B".charCodeAt() <= info.column.charCodeAt() &&
              info.column.charCodeAt() <= "M".charCodeAt()
            );
          }),
        ]) * 2
      : 0,
    减去国庆休假周一到周三3天晚自习: ~outTeachers.indexOf(teacher)
      ? _.filter(wanzixiArray, (info) => {
          return (
            "B".charCodeAt() <= info.charCodeAt() &&
            info.charCodeAt() <= "M".charCodeAt()
          );
        }).length * 1.9
      : 0,
    减去21大数据与会计第8周实训:
      teacher === "肖楚煜"
        ? 0
        : shixunHeMinusKeshiXishu(infos, ["21大数据与会计"]) * 2,
    加上21大数据与会计第8周实训:
      teacher === "李含笑" ? clazzConfigs["21大数据与会计"].shixunZhou : 0,
    "减去肖楚煜6(周四、周五)休假课程":
      teacher === "肖楚煜"
        ? _.filter(wanzixiArray, (info) => {
            return (
              "N".charCodeAt() <= info.charCodeAt() &&
              info.charCodeAt() <= "S".charCodeAt()
            );
          }).length *
            1.9 +
          reduceDakeShu([
            ..._.filter(infos, (info) => {
              return (
                "N".charCodeAt() <= info.column.charCodeAt() &&
                info.column.charCodeAt() <= "S".charCodeAt()
              );
            }),
          ]) *
            2
        : 0,
    "减去肖楚煜7、8周休假课程": teacher === "肖楚煜" ? weekKeshiShu * 2 : 0,
    加上易娟替换肖楚煜课程: teacher === "易娟" ? 18 * 2 : 0,
    加上徐雨替换肖楚煜课程: teacher === "徐雨" ? (6 - 1) * 2 : 0,
  };
  return ret;
}