function _1(md){return(
md`# FileAttachment.xlsx()

Observable supports parsing data from Microsoft Excel XLSX (.xlsx) [file attachments](file-attachments) using [ExcelJS](https://www.npmjs.com/package/exceljs).

Our focus is on the _data_ in XLSX files. In contrast, styling and presentation information (such as widths, fonts, formatting, frozen panes) is not as easily available, but still retrievable using ExcelJS directly.
`
)}

function _2(md){return(
md`## Usage
To use, simply call \`.xlsx()\` on a file attachment. Here, we’ll use \`FileAttachment()\` to attach data from the Federal Aviation Administration’s [reports of lasers pointed at aircraft](https://www.faa.gov/about/initiatives/lasers/laws/).`
)}

function _workbook(FileAttachment){return(
FileAttachment("2022-2023学年20、21、22级第一学期课表+周历暂定稿 (下埠教学点)@1.xlsx").xlsx()
)}

function _abc(){return(
`周家忠合1
乐素颖
黄伟英
周家忠合1
乐素颖
黄伟英
周家忠
乐素颖
黄伟英
周家忠合2
曾娜
黄伟英
周家忠合2
曾娜
黄伟英
周家忠合3
曾娜
黄伟英
周家忠
杨洪梅
黄伟英
周家忠合3
杨洪梅
谢子文
周家忠合4
杨洪梅
谢子文
周家忠合4
乐素颖
谢子文
彭润华
莫俊晶
宋丹
贺年明
陈明
曾婧玉
杨秀庭
贺春
曾娜
莫俊晶
宋丹
贺年明
陈明
曾婧玉
杨秀庭
贺春
杨洪梅
莫俊晶
宋丹
贺年明
陈明
曾婧玉
杨秀庭
贺春
朱和智
余娜合1
肖卷
黄伟英
朱和智合1
张华合1
李文钰
王毅
朱和智合1
张华合1
李文钰
王毅
朱和智
张华合2
肖卷
黄伟英
朱和智合2
张华合2
肖卷
王毅
朱和智合2
张华合3
肖卷
王毅
张远合1
张华合3
王敏
王毅
张远合2
张华
王敏
王慧
张远合2
贺春
王敏
王慧
张远合1
余娜合1
肖卷
王慧
张远合3
余娜合2
王敏
谢子文
张远合3
余娜合2
王敏
谢子文
张远合4
余娜合3
李文钰
王慧
朱朋
杨秀庭
曾婧玉
张远合4
余娜合3
李文钰
王慧
朱朋
杨秀庭
曾婧玉
`.replace(/合\d?/g,"")
)}

function _xx(abc){return(
Array.from(new Set(abc.split("\n"))).join("\n")
)}

function _6(md){return(
md`If you expand (click the black triangle of) the Workbook in the previous cell, you can see that the workbook includes an array of the sheet names in the original file. Using that array, you can access individual sheets of the XLSX file:`
)}

function _7(workbook){return(
workbook.sheet
)}

function _sheet1(workbook){return(
workbook.sheet("总课表")
)}

function _9(sheet1)
{
  let orders = {};
  let repeatedArr=[];
  for(let j=2;j<20;j++){
    let column = sheet1.columns[j];
    let arr=[];
    orders[column]=[];
    for(let i = 2;i< sheet1.length;i++){
      //if(!sheet1[i]){continue;}
      let b = sheet1[i][column]
      if(!b){continue;}
      let splits = b.split("\n");
      let room = splits[2];
      orders[column].push(`${room} ${splits[1]}`);
      if(!~arr.indexOf(room)){
       arr.push(room)
      }else if(!~room.indexOf("践行楼")){
        repeatedArr.push({ i, label:`${sheet1[i]["A"]}`,column ,room,name:splits[1]})
      }
      
    }
    orders[column].sort()
  }
  return {repeatedArr,orders};
}


function _10(md){return(
md`From there, \`Inputs.table()\` allows us to see the data in table format:`
)}

function _11(Inputs,sheet1){return(
Inputs.table(sheet1)
)}

function _12(md){return(
md`Here are the methods available for working with XLSX files:`
)}

function _13(md){return(
md`### _workbook_.sheetNames

Returns an array of sheet names from the workbook.`
)}

function _14(workbook){return(
workbook.sheetNames
)}

function _15(md){return(
md`### _workbook_.sheet(_name_[, {_range_, _headers_}])

Returns an array of objects representing the cells in a specific sheet from the workbook.

- Values are coerced to their corresponding JavaScript types: numbers, strings, Date objects.
- Dates are interpreted in UTC.
- Formula results are included, but formula definitions ignored. Formula errors are coerced to \`NaN\`.
- Hyperlinks are returned as strings, with a space between URL and text if they differ.
- Empty cells are skipped: objects will not include fields or values for them, but empty rows are kept.
- Row numbers from the source sheet are included as a non-enumerable \`"#"\` property to assist with recognition and range specification.`
)}

function _16(md){return(
md`___name___ is a string or number representing the sheet name from which you plan to extract data. 
- The string form of the argument must match a name in \`sheetNames\` (example shown in Usage section).
- The number form of the argument represents the order in which the sheet names occur in \`sheetNames\` (zero-indexed).`
)}

function _17(workbook){return(
workbook.sheet(0)
)}

function _18(md){return(
md`___range___ is a string specifying a rectangular range of cells to extract from the sheet. For example, \`"B4:K123"\` specifies a range from top-left cell B4 to bottom-right cell K123, inclusive. If no range is specified, the entire sheet is extracted by default.

Similar to spreadsheets, the column or row part of the start or end may be omitted to mean the entire column or row; that is, \`"4:123"\` are rows 4 through 123 inclusive for all columns. Extending the standard syntax, you may omit a start or end specifier on either side of the colon (\`:\`) to leave it unbounded. For example, \`"4:"\` means row 4 to the end of the sheet.

Union (\`"A1:B3,D1:G3"\`) and intersection (\`"A1:C3 B2:D4"\`) ranges are not supported currently.`
)}

function _partial(workbook){return(
workbook.sheet(0, { range: "C1:J" })
)}

function _20(Inputs,partial){return(
Inputs.table(partial, { layout: "auto" })
)}

function _21(md){return(
md`___headers___ is a Boolean that, if \`true\`, will treat the first extracted row as column headers and use its cells as field names in returned objects. The default is \`false\`.

If a header value is empty or zero, ABC-type column names will be substituted. Underscores (\`_\`) are appended when avoiding field name conflicts.`
)}

function _data(workbook){return(
workbook.sheet(0, { headers: true, range: ":J" })
)}

function _23(Inputs,data){return(
Inputs.table(data, { layout: "auto" })
)}

function _24(md){return(
md`## ZIP archives and .xlsx files
You can read \`.xlsx\` files that are contained within a ZIP archive. Use [\`FileAttachment.zip()\`](zip) to access the ZIP archive, then use \`.xlsx()\` to read the contents of the file:`
)}

async function _25(FileAttachment)
{
  const zip = await FileAttachment("reports.zip").zip();
  const workbook = await zip.file("Laser_Report_2020.xlsx").xlsx();
  return workbook.sheet(0, { headers: true, range: ":J" });
}


function _26(md){return(
md`Note that zipping \`.xlsx\` files doesn’t result in much smaller file attachments, since the XLSX format is already compressed; however, the technique might be convenient if you prefer to upload a number of spreadsheets all at once.`
)}

function _27(md){return(
md`### Suggestions?

If you have suggestions or improvements, please add your feedback as an [issue on GitHub](https://github.com/observablehq/stdlib/issues).`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["reports.zip", {url: new URL("./files/cf17d2f53ec6eb3a0a17980e05fec58ea6997a63ea6dfe868e232f714474072909727711b6c050166d7df4404d162b4dbbb12df2cc5ec66b8a43c6e362efd8a3.zip", import.meta.url), mimeType: "application/zip", toString}],
    ["2022-2023学年20、21、22级第一学期课表+周历暂定稿 (下埠教学点)@1.xlsx", {url: new URL("./files/60dd152b9e42e805878d45f2e728bba9b3e4be95325e686c74d5fe71a2a43438141d0e29875acedde120045de042d01b90e28f562dbbe1264525760b903500de.xlsx", import.meta.url), mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer("workbook")).define("workbook", ["FileAttachment"], _workbook);
  main.variable(observer("abc")).define("abc", _abc);
  main.variable(observer("xx")).define("xx", ["abc"], _xx);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer()).define(["workbook"], _7);
  main.variable(observer("sheet1")).define("sheet1", ["workbook"], _sheet1);
  main.variable(observer()).define(["sheet1"], _9);
  main.variable(observer()).define(["md"], _10);
  main.variable(observer()).define(["Inputs","sheet1"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer()).define(["workbook"], _14);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer()).define(["md"], _16);
  main.variable(observer()).define(["workbook"], _17);
  main.variable(observer()).define(["md"], _18);
  main.variable(observer("partial")).define("partial", ["workbook"], _partial);
  main.variable(observer()).define(["Inputs","partial"], _20);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer("data")).define("data", ["workbook"], _data);
  main.variable(observer()).define(["Inputs","data"], _23);
  main.variable(observer()).define(["md"], _24);
  main.variable(observer()).define(["FileAttachment"], _25);
  main.variable(observer()).define(["md"], _26);
  main.variable(observer()).define(["md"], _27);
  return main;
}
